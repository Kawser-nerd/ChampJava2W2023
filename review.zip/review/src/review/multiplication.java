/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package review;

/**
 *
 * @author knafi
 */
public class multiplication {
    private double value1;
    private double value2;
     multiplication(double value1, double value2){
        this.value1 = value1;
        this.value2 = value2;  
    }
    public double getMultiplication(){
        return this.value1*this.value2;
    }
    
    
}
