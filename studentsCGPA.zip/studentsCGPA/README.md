# studentsCGPA
this project is given to students as a sample for their projec work

Basically, this program works on a given file, "Result.txt" where the record of students are stored. The file stores student name, student batchNo and their GPAs for eight semesters.

Student class will capture the student name, batch no and their GPAs. For now, there are two students information available in the file, but it could be any number in near future based on the number of registrations.


